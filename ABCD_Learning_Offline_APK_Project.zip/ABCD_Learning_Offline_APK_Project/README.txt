ABCD LEARNING — OFFLINE ANDROID APK PROJECT

This package is an Android Studio project that wraps the complete learning app
inside an Android WebView. The HTML, CSS, JavaScript and learning data are bundled
in app/src/main/assets, so the lessons do not need internet access.

IMPORTANT:
This ZIP is Android source code, NOT a compiled APK file.
A compiled APK cannot be produced in this workspace because Android SDK and
Gradle are not installed here.

BUILD WITH ANDROID STUDIO:
1. Extract this ZIP on a computer with Android Studio installed.
2. Open the extracted ABCD_Learning_Offline_APK_Project folder in Android Studio.
3. Allow Gradle sync and Android SDK downloads to finish.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK at:
   app/build/outputs/apk/debug/app-debug.apk

CLOUD BUILD OPTION:
The included .github/workflows/build-apk.yml can build the APK with GitHub Actions.
Upload this project to a GitHub repository, then open Actions and run
"Build Offline APK". Download the generated artifact named
"ABCD-Learning-Offline-APK".

APP DETAILS:
- App name: ABCD Learning
- Package ID: com.tasmina.abcdlearning
- Minimum Android version: Android 6.0 (API 23)
- Internet permission: not requested
- Learning content: bundled locally in the APK

PRONUNCIATION:
The app uses Android WebView's browser speech synthesis support when available.
Voice availability and installed language voices depend on the Android device.
